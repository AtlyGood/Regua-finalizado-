from kivy.app import App
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.dropdown import DropDown
from kivy.properties import StringProperty, BooleanProperty, NumericProperty
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, Ellipse
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.metrics import dp, sp
import sqlite3
import os
import shutil
import re
from django.contrib.auth.hashers import make_password

usuario = os.getlogin()
Builder.load_file("perfil.kv")

class ProfileImage(ButtonBehavior, Image):
    """Widget personalizado para exibir imagem de perfil com formato circular"""
    def __init__(self, **kwargs):
        super(ProfileImage, self).__init__(**kwargs)
        self.allow_stretch = True
        self.keep_ratio = False
        
    def on_size(self, *args):
        # Remove o canvas anterior para evitar sobreposição
        self.canvas.before.clear()
        with self.canvas.before:
            # Borda circular - MESMA COR DO AGENDAMENTO_BARB
            Color(0.886, 0.898, 0.918, 1)
            Ellipse(pos=self.pos, size=self.size)
            
            # Imagem arredondada - MESMO ESTILO DO AGENDAMENTO_BARB
            Color(1, 1, 1, 1)
            Ellipse(
                pos=(self.x + dp(2), self.y + dp(2)), 
                size=(self.width - dp(4), self.height - dp(4)),
                source=self.source
            )

class ConfirmationPopup(Popup):
    def __init__(self, callback, **kwargs):
        super(ConfirmationPopup, self).__init__(**kwargs)
        self.callback = callback
        self.title = "Confirmar Exclusão"
        self.size_hint = (0.7, 0.4)
        
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        content.add_widget(Label(
            text="Tem certeza que deseja excluir sua conta permanentemente?\nEsta ação não pode ser desfeita.",
            text_size=(self.width - 20, None)
        ))
        
        buttons_layout = BoxLayout(size_hint_y=0.3, spacing=10)
        btn_cancel = Button(text="Cancelar")
        btn_confirm = Button(text="Confirmar Exclusão", background_color=(1, 0.3, 0.3, 1))
        
        btn_cancel.bind(on_release=self.dismiss)
        btn_confirm.bind(on_release=self.confirm_delete)
        
        buttons_layout.add_widget(btn_cancel)
        buttons_layout.add_widget(btn_confirm)
        content.add_widget(buttons_layout)
        
        self.content = content
    
    def confirm_delete(self, instance):
        self.dismiss()
        if self.callback:
            self.callback()

class PhotoPopup(Popup):
    def __init__(self, callback, **kwargs):
        super(PhotoPopup, self).__init__(**kwargs)
        self.callback = callback
        self.title = "Alterar Foto"
        self.size_hint = (0.8, 0.6)
        
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        self.file_chooser = FileChooserIconView(filters=['*.png', '*.jpg', '*.jpeg'])
        content.add_widget(self.file_chooser)
        
        buttons_layout = BoxLayout(size_hint_y=0.2, spacing=10)
        btn_cancel = Button(text="Cancelar")
        btn_select = Button(text="Selecionar Foto")
        
        btn_cancel.bind(on_release=self.dismiss)
        btn_select.bind(on_release=self.select_photo)
        
        buttons_layout.add_widget(btn_cancel)
        buttons_layout.add_widget(btn_select)
        content.add_widget(buttons_layout)
        
        self.content = content
    
    def select_photo(self, instance):
        if self.file_chooser.selection:
            photo_path = self.file_chooser.selection[0]
            self.dismiss()
            if self.callback:
                self.callback(photo_path)

class CustomDropDown(DropDown):
    pass

class MenuButton(Button):
    pass

class PhoneTextInput(TextInput):
    """TextInput com formatação automática para telefone"""
    
    def __init__(self, **kwargs):
        super(PhoneTextInput, self).__init__(**kwargs)
        self.bind(text=self.format_phone)
    
    def format_phone(self, instance, value):
        """Formata o telefone enquanto digita"""
        # Remove caracteres não numéricos
        numbers = re.sub(r'\D', '', value)
        
        # Aplica a formatação
        if len(numbers) <= 2:
            formatted = f"({numbers}"
        elif len(numbers) <= 7:
            formatted = f"({numbers[:2]}) {numbers[2:]}"
        elif len(numbers) <= 11:
            formatted = f"({numbers[:2]}) {numbers[2:7]}-{numbers[7:]}"
        else:
            # Limita a 11 dígitos
            numbers = numbers[:11]
            formatted = f"({numbers[:2]}) {numbers[2:7]}-{numbers[7:]}"
        
        # Atualiza o texto sem disparar o evento novamente
        if formatted != value:
            self.unbind(text=self.format_phone)
            self.text = formatted
            self.bind(text=self.format_phone)
    
    def insert_text(self, substring, from_undo=False):
        """Permite apenas números e limita o tamanho"""
        # Permite apenas números
        numbers = re.sub(r'\D', '', substring)
        current_text = re.sub(r'\D', '', self.text)
        
        # Limita a 11 dígitos
        if len(current_text) + len(numbers) > 11:
            numbers = numbers[:11 - len(current_text)]
        
        return super(PhoneTextInput, self).insert_text(numbers, from_undo=from_undo)

class CPFTextInput(TextInput):
    """TextInput com formatação automática para CPF"""
    
    def __init__(self, **kwargs):
        super(CPFTextInput, self).__init__(**kwargs)
        self.bind(text=self.format_cpf)
    
    def format_cpf(self, instance, value):
        """Formata o CPF enquanto digita"""
        # Remove caracteres não numéricos
        numbers = re.sub(r'\D', '', value)
        
        # Aplica a formatação
        if len(numbers) <= 3:
            formatted = numbers
        elif len(numbers) <= 6:
            formatted = f"{numbers[:3]}.{numbers[3:]}"
        elif len(numbers) <= 9:
            formatted = f"{numbers[:3]}.{numbers[3:6]}.{numbers[6:]}"
        elif len(numbers) <= 11:
            formatted = f"{numbers[:3]}.{numbers[3:6]}.{numbers[6:9]}-{numbers[9:]}"
        else:
            # Limita a 11 dígitos
            numbers = numbers[:11]
            formatted = f"{numbers[:3]}.{numbers[3:6]}.{numbers[6:9]}-{numbers[9:]}"
        
        # Atualiza o texto sem disparar o evento novamente
        if formatted != value:
            self.unbind(text=self.format_cpf)
            self.text = formatted
            self.bind(text=self.format_cpf)
    
    def insert_text(self, substring, from_undo=False):
        """Permite apenas números e limita o tamanho"""
        # Permite apenas números
        numbers = re.sub(r'\D', '', substring)
        current_text = re.sub(r'\D', '', self.text)
        
        # Limita a 11 dígitos
        if len(current_text) + len(numbers) > 11:
            numbers = numbers[:11 - len(current_text)]
        
        return super(CPFTextInput, self).insert_text(numbers, from_undo=from_undo)

class ProfileScreen(Screen):
    profile_photo = StringProperty('')
    is_mobile = BooleanProperty(False)
    profile_size = NumericProperty(dp(40))
    tipo_usuario = StringProperty('cliente')
    titulo_tela = StringProperty('Perfil')
    
    def __init__(self, **kwargs):
        super(ProfileScreen, self).__init__(**kwargs)
        self.dados_usuario = {}
        self.dropdown = CustomDropDown()
        Window.bind(on_resize=self.on_window_resize)
        Clock.schedule_once(self.init_ui, 0.1)
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.determinar_tipo_usuario()
        self.carregar_dados_usuario()
        self.carregar_foto_perfil()
        self.create_dropdown()
        self.atualizar_interface()
    
    def init_ui(self, dt):
        self.check_screen_size()
        
    def on_window_resize(self, window, width, height):
        self.check_screen_size()
        
    def check_screen_size(self):
        """Verifica se está em modo mobile baseado na largura da tela"""
        self.is_mobile = Window.width < dp(768)
        
        # Ajustar tamanho da foto baseado na tela
        if self.is_mobile:
            self.profile_size = dp(40)
        else:
            self.profile_size = dp(40)
    
    def determinar_tipo_usuario(self):
        """Determina se o usuário é cliente ou barbearia"""
        app = App.get_running_app()
        if hasattr(app, 'tipo_usuario'):
            self.tipo_usuario = app.tipo_usuario.lower()
        else:
            # Fallback: verificar no banco de dados
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                cursor.execute("SELECT tipo FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                if resultado:
                    self.tipo_usuario = resultado[0].lower()
                conn.close()
            except:
                self.tipo_usuario = 'cliente'
        
        # Atualizar título da tela
        if self.tipo_usuario == 'barbearia':
            self.titulo_tela = "Perfil da Barbearia"
        else:
            self.titulo_tela = "Perfil do Cliente"
    
    def atualizar_interface(self):
        """Atualiza a interface baseada no tipo de usuário"""
        if hasattr(self, 'ids'):
            # Atualizar campos específicos para barbearia se necessário
            if self.tipo_usuario == 'barbearia' and 'label_titulo' in self.ids:
                self.ids.label_titulo.text = "Perfil da Barbearia"
            elif 'label_titulo' in self.ids:
                self.ids.label_titulo.text = "Perfil do Cliente"
    
    def create_dropdown(self):
        """Cria o menu dropdown com as opções corretas para cada tipo de usuário"""
        self.dropdown.clear_widgets()
        
        # Opções específicas para cada tipo de usuário
        if self.tipo_usuario == 'barbearia':
            opcoes = [
                ('Cadastrar Barbearia', self.go_to_cadastrar_barbearia),
                ('Agendamentos', self.go_to_agendamentos_barb),
                ('Minha Barbearia', self.go_to_minha_barbearia),
                ('Sair', self.logout)
            ]
        else:  # cliente
            opcoes = [
                ('Barbearias Disponíveis', self.go_to_barbearias),
                ('Meus Agendamentos', self.go_to_agendamentos),
                ('Sair', self.logout)
            ]
        
        for text, callback in opcoes:
            btn = MenuButton(
                text=text,
                size_hint_y=None,
                height=dp(50),
                background_color=(1, 1, 1, 1),
                color=(1, 0.3, 0.3, 1) if text == 'Sair' else (0, 0, 0, 1),
                font_size=sp(16)
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def open_menu(self, button):
        """Abre o menu dropdown"""
        self.dropdown.open(button)
    
    # FUNÇÕES DE NAVEGAÇÃO PARA BARBEARIA
    def go_to_cadastrar_barbearia(self, instance):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'cadastro_barbearia'
            self.dropdown.dismiss()
    
    def go_to_minha_barbearia(self, instance):
        self.manager.current = 'editar_barbearia'
        self.dropdown.dismiss()
    
    # FUNÇÕES DE NAVEGAÇÃO PARA CLIENTE
    def go_to_barbearias(self, instance):
        """Navega para a tela de barbearias"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'barbearias'
        self.dropdown.dismiss()
    
    # FUNÇÃO COMUM PARA AMBOS
    def go_to_agendamentos(self, instance):
        """Navega para a tela de agendamentos"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'agendamento_cliente'
        self.dropdown.dismiss()

    def go_to_agendamentos_barb(self, instance):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'agendamento_barbeiro'
            self.dropdown.dismiss()

    def logout(self, instance):
        """Realiza logout"""
        self.dropdown.dismiss()
        app = App.get_running_app()
        app.usuario_id = None
        app.logado = False
        app.foto_perfil = None
        app.tipo_usuario = None
        if hasattr(self, 'manager') and self.manager:
            self.manager.current = 'login'
    
    def carregar_dados_usuario(self):
        """Carrega os dados do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT nome, sobrenome, email, telefone, cpf, foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado:
                    self.dados_usuario = {
                        'nome': resultado[0],
                        'sobrenome': resultado[1],
                        'email': resultado[2],
                        'telefone': resultado[3] or '',
                        'cpf': resultado[4] or '',
                        'foto_perfil': resultado[5] or ''
                    }
                    
                    # Preenche os campos do formulário
                    if hasattr(self, 'ids'):
                        if 'input_nome' in self.ids:
                            self.ids.input_nome.text = self.dados_usuario['nome']
                        if 'input_sobrenome' in self.ids:
                            self.ids.input_sobrenome.text = self.dados_usuario['sobrenome']
                        if 'input_email' in self.ids:
                            self.ids.input_email.text = self.dados_usuario['email']
                        if 'input_telefone' in self.ids:
                            # Aplica formatação automática
                            telefone_limpo = self.dados_usuario['telefone'].replace('(', '').replace(')', '').replace(' ', '').replace('-', '')
                            if telefone_limpo:
                                self.ids.input_telefone.text = telefone_limpo
                        if 'input_cpf' in self.ids:
                            # Aplica formatação automática
                            cpf_limpo = self.dados_usuario['cpf'].replace('.', '').replace('-', '')
                            if cpf_limpo:
                                self.ids.input_cpf.text = cpf_limpo
                
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar dados do usuário: {e}")
                self.mostrar_popup("Erro", "Erro ao carregar dados do usuário")
    
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                        foto_path = os.path.join(base_path, filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids'):
                            if 'profile_image' in self.ids:
                                self.ids.profile_image.source = foto_path
                            if 'profile_pic_nav' in self.ids:
                                self.ids.profile_pic_nav.source = foto_path
                    else:
                        self.definir_imagem_padrao()
                else:
                    self.definir_imagem_padrao()
                
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
                self.definir_imagem_padrao()
        else:
            self.definir_imagem_padrao()
    
    def definir_imagem_padrao(self):
        """Define uma imagem padrão quando não há foto"""
        self.profile_photo = 'assets/default_profile.png'
        if hasattr(self, 'ids'):
            if 'profile_image' in self.ids:
                self.ids.profile_image.source = 'assets/default_profile.png'
            if 'profile_pic_nav' in self.ids:
                self.ids.profile_pic_nav.source = 'assets/default_profile.png'
    
    def show_confirmation_popup(self):
        """Abre popup de confirmação para excluir conta"""
        popup = ConfirmationPopup(callback=self.confirmar_exclusao)
        popup.open()
    
    def cancelar(self):
        """Voltar para a tela anterior (home)"""
        if hasattr(self, 'manager') and self.manager:
            if self.tipo_usuario == 'barbearia':
                self.manager.current = 'home_barbeiro'
            else:
                self.manager.current = 'home'
    
    def excluir_conta(self):
        """Abre popup de confirmação para excluir conta"""
        self.show_confirmation_popup()
    
    def confirmar_exclusao(self):
        """Confirma e executa a exclusão da conta"""
        try:
            app = App.get_running_app()
            if hasattr(app, 'usuario_id') and app.usuario_id:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                # Remove foto de perfil se existir
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    if os.path.exists(foto_path):
                        os.remove(foto_path)
                
                # Exclui usuário
                cursor.execute("DELETE FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                conn.commit()
                conn.close()
                
                # Limpa sessão
                app.usuario_id = None
                app.logado = False
                app.foto_perfil = None
                app.tipo_usuario = None
                
                self.mostrar_popup("Sucesso", "Conta excluída com sucesso!")
                if hasattr(self, 'manager') and self.manager:
                    self.manager.current = 'login'
                
        except Exception as e:
            print(f"Erro ao excluir conta: {e}")
            self.mostrar_popup("Erro", "Erro ao excluir conta")
    
    def salvar_alteracoes(self):
        """Salva as alterações do perfil no banco de dados"""
        try:
            app = App.get_running_app()
            if hasattr(app, 'usuario_id') and app.usuario_id:
                # Obtém dados dos campos
                nome = self.ids.input_nome.text if hasattr(self, 'ids') and 'input_nome' in self.ids else ''
                sobrenome = self.ids.input_sobrenome.text if hasattr(self, 'ids') and 'input_sobrenome' in self.ids else ''
                email = self.ids.input_email.text if hasattr(self, 'ids') and 'input_email' in self.ids else ''
                
                # Remove formatação dos campos formatados
                telefone = re.sub(r'\D', '', self.ids.input_telefone.text) if hasattr(self, 'ids') and 'input_telefone' in self.ids else ''
                cpf = re.sub(r'\D', '', self.ids.input_cpf.text) if hasattr(self, 'ids') and 'input_cpf' in self.ids else ''
                
                senha = self.ids.input_senha.text if hasattr(self, 'ids') and 'input_senha' in self.ids else ''
                
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                # Atualiza dados básicos
                cursor.execute("""
                    UPDATE regua2_usuario 
                    SET nome = ?, sobrenome = ?, email = ?, telefone = ?, cpf = ?
                    WHERE id = ?
                """, (nome, sobrenome, email, telefone, cpf, app.usuario_id))
                
                # Atualiza senha se fornecida
                if senha:
                    senha_hash = make_password(senha)
                    cursor.execute("UPDATE regua2_usuario SET senha = ? WHERE id = ?", 
                                 (senha_hash, app.usuario_id))
                
                conn.commit()
                conn.close()
                
                self.mostrar_popup("Sucesso", "Alterações salvas com sucesso!")
                self.cancelar()  # Volta para a tela home correta
                
        except Exception as e:
            print(f"Erro ao salvar alterações: {e}")
            self.mostrar_popup("Erro", "Erro ao salvar alterações")
    
    def alterar_foto(self):
        """Abre popup para selecionar nova foto"""
        popup = PhotoPopup(callback=self.salvar_foto)
        popup.open()
    
    def salvar_foto(self, photo_path):
        """Salva a nova foto de perfil"""
        try:
            app = App.get_running_app()
            if hasattr(app, 'usuario_id') and app.usuario_id:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                # Remove foto antiga se existir
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_antiga = resultado[0]
                    if os.path.exists(foto_antiga):
                        os.remove(foto_antiga)
                
                # Salva nova foto
                filename = f"user_{app.usuario_id}_{os.path.basename(photo_path)}"
                destino = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil\\{filename}"
                
                # Copia arquivo para destino
                shutil.copy2(photo_path, destino)
                
                # Atualiza banco
                cursor.execute("UPDATE regua2_usuario SET foto_perfil = ? WHERE id = ?", 
                             (f"perfil/{filename}", app.usuario_id))
                conn.commit()
                conn.close()
                
                # Atualiza interface
                self.carregar_foto_perfil()
                self.mostrar_popup("Sucesso", "Foto alterada com sucesso!")
                
        except Exception as e:
            print(f"Erro ao salvar foto: {e}")
            self.mostrar_popup("Erro", "Erro ao alterar foto")
    
    def mostrar_popup(self, title, message):
        """Exibe um popup de mensagem"""
        popup = Popup(title=title,
                     content=Label(text=message, padding=20),
                     size_hint=(0.7, 0.3))
        popup.open()