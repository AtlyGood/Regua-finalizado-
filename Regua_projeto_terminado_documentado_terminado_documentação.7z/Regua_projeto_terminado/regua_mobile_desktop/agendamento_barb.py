# Importações principais do Kivy (componentes de interface)
from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.dropdown import DropDown
from kivy.uix.modalview import ModalView
from kivy.properties import StringProperty, BooleanProperty, ListProperty, NumericProperty, ObjectProperty
from kivy.metrics import dp  # padroniza tamanhos em diferentes telas
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.clock import Clock  # usado para agendar atualizações de interface
import sqlite3
import os
import requests
from kivy.lang import Builder
from datetime import datetime, timedelta
import json

# Captura o nome do usuário do Windows (usado no caminho do banco)
usuario = os.getlogin()

# Carrega o arquivo KV associado a esta tela
Builder.load_file('agendamento_barb.kv')

class CustomDropDown(DropDown):
    """Menu suspenso personalizado usado no canto superior da tela."""
    pass

class MenuButton(Button):
    """Botão estilizado dentro do menu dropdown."""
    pass

class AgendamentoBarbCard(BoxLayout):
    """
    Representa visualmente um cartão de agendamento.
    Exibe informações do cliente e permite confirmar/cancelar.
    """
    # Propriedades dinâmicas do Kivy (atualizam automaticamente na interface)
    agendamento_id = StringProperty('')
    cliente_nome = StringProperty('')
    cliente_telefone = StringProperty('')
    cliente_email = StringProperty('')
    data_agendamento = StringProperty('')
    horario_agendamento = StringProperty('')
    status = StringProperty('pendente')
    posicao = NumericProperty(0)
    foto_perfil = StringProperty('')
    
    def __init__(self, **kwargs):
        super(AgendamentoBarbCard, self).__init__(**kwargs)
        # Aguarda 1 frame antes de inicializar completamente (evita erro de IDs)
        Clock.schedule_once(self.finalizar_inicializacao)
    
    def finalizar_inicializacao(self, dt):
        """Chamado após a construção do layout."""
        self.atualizar_interface()
    
    def atualizar_interface(self, *args):
        """Atualiza cores, botões e posição conforme o status."""
        if hasattr(self, 'ids'):
            # Cores e comportamento por status
            if self.status == 'cancelado':
                self.ids.status_label.color = (0.894, 0.102, 0.110, 1)  # Vermelho
                self.ids.confirmar_btn.opacity = 0
                self.ids.confirmar_btn.disabled = True
                self.ids.cancelar_btn.opacity = 0
                self.ids.cancelar_btn.disabled = True
            elif self.status == 'confirmado':
                self.ids.status_label.color = (0.156, 0.545, 0.270, 1)  # Verde
                self.ids.confirmar_btn.opacity = 0
                self.ids.confirmar_btn.disabled = True
                self.ids.cancelar_btn.opacity = 1
                self.ids.cancelar_btn.disabled = False
            else:  # pendente
                self.ids.status_label.color = (0.854, 0.647, 0.125, 1)  # Amarelo
                self.ids.confirmar_btn.opacity = 1
                self.ids.cancelar_btn.opacity = 1
            
            # Mostra posição na fila apenas para pendentes
            if self.status == 'pendente':
                self.ids.posicao_label.text = f'{self.posicao}º'
            else:
                self.ids.posicao_label.text = '-'

class ConfirmacaoModal(ModalView):
    """Modal (janela flutuante) para confirmar ação."""
    message = StringProperty('')
    callback = ObjectProperty(None)
    
    def __init__(self, message, callback, **kwargs):
        super().__init__(**kwargs)
        self.message = message
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False

class CancelamentoModal(ModalView):
    """Modal para confirmar cancelamento."""
    message = StringProperty('')
    callback = ObjectProperty(None)
    
    def __init__(self, message, callback, **kwargs):
        super().__init__(**kwargs)
        self.message = message
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False

class AgendamentoBarbScreen(Screen):
    """
    Tela onde o barbeiro visualiza, confirma e cancela agendamentos.
    """
    agendamentos_data = ListProperty([])
    profile_photo = StringProperty('')
    is_mobile = BooleanProperty(False)
    filtro_data = StringProperty('')
    filtro_status = StringProperty('all')
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.modal = None
        self.dropdown = CustomDropDown()
        
        # Ajusta layout conforme tamanho da janela (responsividade)
        from kivy.core.window import Window
        Window.bind(on_resize=self.on_window_resize)
        self.check_screen_size()
    
    def on_window_resize(self, window, width, height):
        """Atualiza layout quando a janela é redimensionada."""
        self.check_screen_size()
    
    def check_screen_size(self):
        """Define se o app está em modo 'mobile' baseado na largura."""
        from kivy.core.window import Window
        self.is_mobile = Window.width < dp(768)
    
    def on_enter(self):
        """Executado sempre que a tela é aberta."""
        self.carregar_agendamentos()
        self.carregar_foto_perfil()
        self.create_dropdown()
    
    def create_dropdown(self):
        """Cria as opções do menu do barbeiro."""
        self.dropdown.clear_widgets()
        options = [
            ('Cadastrar Barbearia', self.go_to_cadastrar_barbearia),
            ('Agendamentos', self.go_to_agendamentos),
            ('Minha Barbearia', self.go_to_minha_barbearia),
            ('Sair', self.logout)
        ]
        for text, callback in options:
            btn = MenuButton(
                text=text,
                size_hint_y=None,
                height=dp(50),
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1]
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def open_dropdown(self, button):
        """Abre o menu suspenso."""
        self.create_dropdown()
        self.dropdown.open(button)
    
    def carregar_foto_perfil(self):
        """Busca a foto do barbeiro no banco SQLite."""
        app = App.get_running_app()
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
            resultado = cursor.fetchone()
            
            if resultado and resultado[0]:
                self.profile_photo = resultado[0]
            conn.close()
        except Exception as e:
            print(f"Erro ao carregar foto: {e}")
    
    def carregar_agendamentos(self):
        """Carrega todos os agendamentos da barbearia do barbeiro."""
        app = App.get_running_app()
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # Busca ID da barbearia vinculada ao barbeiro
            cursor.execute("SELECT id FROM regua2_barbearia WHERE usuario_id = ?", (app.usuario_id,))
            barbearia = cursor.fetchone()
            if not barbearia:
                print("Nenhuma barbearia encontrada.")
                return
            
            barbearia_id = barbearia[0]
            
            # Busca agendamentos e junta com dados dos clientes
            cursor.execute("""
                SELECT a.id, a.cliente_id, a.data, a.horario, a.confirmado, a.realizado,
                    u.nome, u.sobrenome, u.telefone, u.email
                FROM regua2_agendamento a
                JOIN regua2_usuario u ON a.cliente_id = u.id
                WHERE a.barbearia_id = ?
                ORDER BY a.data, a.horario
            """, (barbearia_id,))
            
            # Processa os resultados em uma lista
            agendamentos = cursor.fetchall()
            self.agendamentos_data = []
            
            for agendamento in agendamentos:
                (aid, cid, data, hora, confirmado, realizado, nome, sobrenome, tel, email) = agendamento
                
                # Define o status com base nas flags do banco
                if realizado:
                    status = 'concluido'
                elif confirmado:
                    status = 'confirmado'
                else:
                    status = 'pendente'
                
                self.agendamentos_data.append({
                    'id': str(aid),
                    'cliente_nome': f"{nome} {sobrenome}",
                    'cliente_telefone': tel or 'Telefone não informado',
                    'cliente_email': email or 'E-mail não informado',
                    'data_agendamento': data,
                    'horario_agendamento': hora,
                    'status': status,
                })
            
            conn.close()
            self.organizar_agendamentos()
        except Exception as e:
            print(f"Erro ao carregar agendamentos: {e}")
    
    def organizar_agendamentos(self):
        """Ordena e atualiza posição na fila."""
        status_order = {'pendente': 1, 'confirmado': 2, 'concluido': 3}
        self.agendamentos_data.sort(key=lambda x: status_order.get(x['status'], 4))
        self.aplicar_filtros()
    
    def confirmar_agendamento(self, agendamento_id):
        """Exibe modal e confirma o agendamento."""
        def confirmar(instance):
            self.executar_confirmacao(agendamento_id)
            self.modal.dismiss()
            self.carregar_agendamentos()
        
        self.modal = ConfirmacaoModal("Deseja confirmar este agendamento?", confirmar)
        self.modal.open()
    
    def cancelar_agendamento(self, agendamento_id):
        """Exibe modal e cancela o agendamento."""
        def confirmar_cancelamento(instance):
            self.executar_cancelamento(agendamento_id)
            self.modal.dismiss()
            self.carregar_agendamentos()
        
        self.modal = CancelamentoModal("Tem certeza que deseja cancelar?", confirmar_cancelamento)
        self.modal.open()
    
    def executar_confirmacao(self, agendamento_id):
        """Atualiza o status no banco como confirmado."""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            cursor.execute("UPDATE regua2_agendamento SET confirmado = 1 WHERE id = ?", (agendamento_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao confirmar: {e}")
    
    def executar_cancelamento(self, agendamento_id):
        """Remove o agendamento do banco."""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM regua2_agendamento WHERE id = ?", (agendamento_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Erro ao cancelar: {e}")
    
    def voltar_home(self):
        """Volta para a tela inicial do barbeiro."""
        self.manager.current = 'home_barbeiro'
    
    def ir_para_perfil(self):
        """Vai para a tela de perfil."""
        self.manager.current = 'perfil'
    
    def logout(self, instance):
        """Realiza logout e retorna à tela de login."""
        app = App.get_running_app()
        app.usuario_id = None
        self.manager.current = 'login'
