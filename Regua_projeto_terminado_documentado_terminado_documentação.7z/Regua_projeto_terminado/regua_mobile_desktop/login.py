"""
Módulo de tela de login do aplicativo
Utiliza Django para verificação de senha e SQLite para dados de usuário
"""
from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
import sqlite3
from kivy.app import App
import os 
import django
from django.conf import settings

# Obtém o nome de usuário do sistema
usuario = os.getlogin()

"""
Configuração do Django para usar a mesma criptografia de senha
"""
if not settings.configured:
    settings.configure(
        SECRET_KEY='django-insecure-sua-chave-secreta-aqui',
        USE_TZ=True,
    )
    django.setup()

from django.contrib.auth.hashers import check_password

# Carrega o arquivo KV do login
from kivy.lang import Builder
Builder.load_file('login.kv')


"""
Tela de login do aplicativo
Gerencia autenticação de usuários com verificação Django
"""
class LoginScreen(Screen):
    def fazer_login(self):
        """Realiza o login do usuário com verificação Django"""
        # Obtém os valores dos campos de entrada
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()
        
        # Verifica se os campos estão preenchidos
        if not email or not senha:
            self.ids.mensagem_erro.text = "Preencha todos os campos"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        # Conecta ao banco de dados
        conn = self.conectar_banco()
        if conn:
            try:
                cursor = conn.cursor()
                # Consulta o usuário no banco de dados
                cursor.execute("SELECT id, senha, tipo, nome, sobrenome FROM regua2_usuario WHERE email = ?", (email,))
                resultado = cursor.fetchone()
                
                if resultado:
                    usuario_id, senha_hash, tipo_usuario, nome, sobrenome = resultado
                    
                    # Verifica a senha usando a criptografia do Django
                    if check_password(senha, senha_hash):
                        self.ids.mensagem_erro.text = ""
                        self.ids.mensagem_erro.color = get_color_from_hex('#00AA00')
                        
                        # Armazena os dados do usuário na aplicação
                        app = App.get_running_app()
                        app.usuario_id = usuario_id
                        app.logado = True
                        app.email_usuario = email
                        app.nome_usuario = f"{nome} {sobrenome}" if nome and sobrenome else nome or sobrenome or ""
                        app.tipo_usuario = tipo_usuario
                        
                        # Limpa os campos de entrada
                        self.ids.email_input.text = ""
                        self.ids.senha_input.text = ""
                        
                        # Redireciona conforme o tipo de usuário
                        if tipo_usuario and str(tipo_usuario).lower().strip() == 'barbearia':
                            self.manager.current = 'home_barbeiro'
                        else:
                            self.manager.current = 'home'
                        
                        return True
                    else:
                        self.ids.mensagem_erro.text = "Senha incorreta"
                        self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                else:
                    self.ids.mensagem_erro.text = "E-mail não encontrado"
                    self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                    
            except sqlite3.Error as e:
                self.ids.mensagem_erro.text = f"Erro ao fazer login: {e}"
                self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            finally:
                conn.close()
        return False
    
    def conectar_banco(self):
        """Conecta ao banco de dados SQLite"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            return conn
        except sqlite3.Error as e:
            print(f"Erro ao conectar ao banco: {e}")
            return None
    
    def ir_para_cadastro(self):
        """Navega para a tela de cadastro"""
        self.manager.current = 'cadastro'
        # Limpa os campos ao navegar para cadastro
        self.ids.email_input.text = ""
        self.ids.senha_input.text = ""
        self.ids.mensagem_erro.text = ""