from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.uix.modalview import ModalView
from kivy.uix.dropdown import DropDown
from kivy.properties import StringProperty, BooleanProperty, ListProperty
from kivy.metrics import dp
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.clock import Clock
import sqlite3
import os
import requests
from kivy.lang import Builder
from datetime import datetime, timezone, timedelta

# Nome do usuário atual (usado para montar caminhos absolutos)
usuario = os.getlogin()
# Carrega o arquivo KV que contém o layout visual
Builder.load_file('barbearias.kv')

# Representa o menu suspenso com as opções do topo da tela
class CustomDropDown(DropDown):
    pass

# Botão usado dentro do menu dropdown
class MenuButton(Button):
    pass

# Representa o card individual de cada barbearia exibida na tela
class BarbeariaCard(BoxLayout):
    barbearia_id = StringProperty('')
    nome = StringProperty('')
    endereco = StringProperty('')
    telefone = StringProperty('')
    status = StringProperty('aberto')
    foto_url = StringProperty('')
    possui_agendamento = BooleanProperty(False)
    
    def __init__(self, **kwargs):
        super(BarbeariaCard, self).__init__(**kwargs)
        # Aguarda a interface ser construída antes de ajustar os botões
        Clock.schedule_once(self.finalizar_inicializacao)
    
    def finalizar_inicializacao(self, dt):
        self.atualizar_interface()
    
    def atualizar_interface(self, *args):
        if hasattr(self, 'ids'):
            if self.possui_agendamento:
                # Caso o usuário já tenha um agendamento ativo
                self.ids.btn_agendar.text = 'Já na fila'
                self.ids.btn_agendar.background_color = (0.231, 0.510, 0.961, 1)  # Azul
                self.ids.btn_agendar.disabled = True
            else:
                # Caso a barbearia esteja aberta
                if self.status == 'aberto':
                    self.ids.btn_agendar.text = 'Entrar na Fila'
                    self.ids.btn_agendar.background_color = (0.133, 0.773, 0.369, 1)  # Verde
                    self.ids.btn_agendar.disabled = False
                else:
                    # Caso esteja fechada
                    self.ids.btn_agendar.text = 'Indisponível'
                    self.ids.btn_agendar.background_color = (0.941, 0.945, 0.949, 1)  # Cinza
                    self.ids.btn_agendar.disabled = True

#Exibe uma janela de confirmação após o agendamento
class ConfirmationModal(ModalView):
    barbearia_nome = StringProperty('')
    
    def __init__(self, barbearia_nome, callback, **kwargs):
        super(ConfirmationModal, self).__init__(**kwargs)
        self.barbearia_nome = barbearia_nome
        self.callback = callback
        self.size_hint = (0.8, 0.4)
        self.auto_dismiss = False
    
    def fechar(self, instance):
        self.dismiss()
        if self.callback:
            self.callback()

# Tela que lista as barbearias e controla o agendamento
class BarbeariasScreen(Screen):
    barbearias_data = ListProperty([]) # Lista de barbearias carregadas do banco
    possui_agendamento_ativo = BooleanProperty(False) # Indica se o usuário já possui um agendamento ativo
    profile_photo = StringProperty('') # Caminho da foto do perfil do usuário
    is_mobile = BooleanProperty(False) # Define se está em modo mobile (responsividade)
    
    def __init__(self, **kwargs):
        super(BarbeariasScreen, self).__init__(**kwargs)
        self.modal = None
        self.dropdown = CustomDropDown()
        
        # Verificar tamanho da tela ao inicializar
        from kivy.core.window import Window
        Window.bind(on_resize=self.on_window_resize)
        self.check_screen_size()
    
    def on_window_resize(self, window, width, height):
        """Atualiza responsividade quando a janela é redimensionada"""
        self.check_screen_size()
    
    def check_screen_size(self):
        """Verifica se está em modo mobile baseado na largura da tela"""
        from kivy.core.window import Window
        from kivy.metrics import dp
        self.is_mobile = Window.width < dp(768)
        
        # Atualizar o app global também
        app = App.get_running_app()
        if hasattr(app, 'is_mobile'):
            app.is_mobile = self.is_mobile
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_barbearias()
        self.verificar_agendamento_ativo()
        self.carregar_foto_perfil()
        self.create_dropdown()
    
    def create_dropdown(self):
        """Cria o menu dropdown"""
        self.dropdown.clear_widgets()
        
        options = [
            ('Barbearias Disponíveis', self.go_to_barbearias),
            ('Meus Agendamentos', self.go_to_agendamentos),
            ('Sair', self.logout)
        ]
        
        # Cria cada botão do menu
        for text, callback in options:
            btn = MenuButton(
                text=text, 
                size_hint_y=None, 
                height=dp(50),
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1]
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def open_dropdown(self, button):
        """Abre o menu dropdown"""
        self.create_dropdown()
        self.dropdown.open(button)
    
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                        foto_path = os.path.join(base_path, filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids') and 'profile_image' in self.ids:
                            self.ids.profile_image.source = foto_path
                
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
    
    def carregar_barbearias(self):
        """Carrega as barbearias do banco de dados"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            cursor.execute("""
                SELECT id, nome_barbearia, endereco, cidade, estado, 
                telefone_comercial, foto_logo, status_barbearia
                FROM regua2_barbearia 
                WHERE ativa = 1
            """)
            
            barbearias = cursor.fetchall()
            self.barbearias_data = []
            
            for barbearia in barbearias:
                # Processar o caminho da foto
                foto_path = barbearia[6] or ''
                if foto_path:
                    # Se o caminho começar com "barbearias/logos/", extrair apenas o nome do arquivo
                    if foto_path.startswith('barbearias/logos/'):
                        filename = foto_path.replace('barbearias/logos/', '')
                    else:
                        filename = foto_path
                    
                    # Construir o caminho absoluto
                    base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos"
                    foto_path = os.path.join(base_path, filename)
                    
                    # Verificar se o arquivo existe
                    if not os.path.exists(foto_path):
                        foto_path = ''  # Usar placeholder se não existir
                
                barbearia_dict = {
                    'id': barbearia[0],
                    'nome': barbearia[1],
                    'endereco': f"{barbearia[3]}, {barbearia[4]}",
                    'telefone': barbearia[5] or 'Telefone não informado',
                    'foto_url': foto_path,
                    'status': barbearia[7] or 'aberto'
                }
                self.barbearias_data.append(barbearia_dict)
            
            conn.close()
            self.atualizar_interface()
            
        except Exception as e:
            print(f"Erro ao carregar barbearias: {e}")
    
    def verificar_agendamento_ativo(self):
        """Verifica se o usuário já possui um agendamento ativo"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT id FROM regua2_agendamento 
                    WHERE cliente_id = ? AND confirmado = 0
                """, (app.usuario_id,))
                
                resultado = cursor.fetchone()
                self.possui_agendamento_ativo = resultado is not None
                conn.close()
                
            except Exception as e:
                print(f"Erro ao verificar agendamento: {e}")
                self.possui_agendamento_ativo = False
    
    def atualizar_interface(self):
        """Atualiza a interface com as barbearias carregadas"""
        if hasattr(self, 'ids') and 'barbearias_grid' in self.ids:
            self.ids.barbearias_grid.clear_widgets()
            
            # Atualizar número de colunas baseado no tamanho da tela
            self.ids.barbearias_grid.cols = 1 if self.is_mobile else 2
            
            for barbearia in self.barbearias_data:
                card = BarbeariaCard(
                    barbearia_id=str(barbearia['id']),
                    nome=barbearia['nome'],
                    endereco=barbearia['endereco'],
                    telefone=barbearia['telefone'],
                    status=barbearia['status'],
                    foto_url=barbearia['foto_url'],
                    possui_agendamento=self.possui_agendamento_ativo
                )
                card.ids.btn_agendar.bind(on_release=lambda instance, bid=barbearia['id'], bnome=barbearia['nome']: 
                    self.entrar_na_fila(bid, bnome))
                self.ids.barbearias_grid.add_widget(card)
    
    def entrar_na_fila(self, barbearia_id, barbearia_nome):
        """Processa o agendamento na barbearia"""
        if self.possui_agendamento_ativo:
            self.mostrar_aviso("Você já possui um agendamento ativo. Cancele ou conclua o atual antes de fazer um novo. atualize a pagina para ver a situação atual da barbearia")
            return
        
        # Verificar status da barbearia
        if not self.verificar_status_barbearia(barbearia_id):
            self.mostrar_aviso("Esta barbearia está fechada no momento.")
            return
        
        # Criar agendamento
        if self.criar_agendamento(barbearia_id):
            self.possui_agendamento_ativo = True
            self.mostrar_confirmacao(barbearia_nome)
            self.atualizar_interface()
    
    def verificar_status_barbearia(self, barbearia_id):
        """Verifica se a barbearia está aberta"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            cursor.execute("SELECT status_barbearia FROM regua2_barbearia WHERE id = ?", (barbearia_id,))
            resultado = cursor.fetchone()
            conn.close()
            
            return resultado and resultado[0] == 'aberto'
            
        except Exception as e:
            print(f"Erro ao verificar status: {e}")
            return False
    
    def criar_agendamento(self, barbearia_id):
        """Cria um agendamento no banco de dados com UTC"""
        app = App.get_running_app()
        if not hasattr(app, 'usuario_id') or not app.usuario_id:
            self.mostrar_aviso("Usuário não logado")
            return False
        
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # USAR UTC explicitamente
            from datetime import datetime, timezone
            agora_utc = datetime.now(timezone.utc)
            
            data_atual_str = agora_utc.date().isoformat()
            hora_atual_str = agora_utc.time().strftime('%H:%M:%S')
            data_criacao_str = agora_utc.strftime('%Y-%m-%d %H:%M:%S')

            
            cursor.execute("""
                INSERT INTO regua2_agendamento 
                (barbearia_id, cliente_id, confirmado, realizado, data, horario, data_criacao)
                VALUES (?, ?, 0, 0, ?, ?, ?)
            """, (barbearia_id, app.usuario_id, data_atual_str, hora_atual_str, data_criacao_str))
            
            conn.commit()
            conn.close()
            return True
                
        except Exception as e:
            print(f"Erro ao criar agendamento: {e}")
            self.mostrar_aviso("Erro ao realizar agendamento")
            return False
    
    def mostrar_confirmacao(self, barbearia_nome):
        """Mostra modal de confirmação"""
        self.modal = ConfirmationModal(
            barbearia_nome=barbearia_nome,
            callback=self.ir_para_agendamentos
        )
        self.modal.open()
    
    def mostrar_aviso(self, mensagem):
        """Mostra um aviso simples"""
        # Aumentei o tamanho para 0.8 de largura e 0.35 de altura
        modal = ModalView(size_hint=(0.8, 0.35), auto_dismiss=True)
        content = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(15))
        
        # Área do texto ocupa 70% do espaço
        label = Label(
            text=mensagem,
            text_size=(dp(350), None),  # Largura fixa maior
            halign='center',
            valign='middle',
            size_hint_y=0.7,  # 70% para o texto
            font_size=dp(16)   # Fonte maior
        )
        content.add_widget(label)
        
        # Botão ocupa 30% do espaço
        btn_ok = Button(
            text='OK',
            size_hint_y=0.3,  # 30% para o botão
            background_color=(0.133, 0.773, 0.369, 1),
            color=(1, 1, 1, 1),
            font_size=dp(16)
        )
        btn_ok.bind(on_release=modal.dismiss)
        content.add_widget(btn_ok)
        
        modal.add_widget(content)
        modal.open()
    
    def go_to_barbearias(self, instance):
        """Navega para barbearias (já está aqui)"""
        self.dropdown.dismiss()
    
    def go_to_agendamentos(self, instance):
        """Navega para a tela de agendamentos"""
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'agendamento_cliente'
        self.dropdown.dismiss()
    
    def ir_para_agendamentos(self):
        """Navega para a tela de agendamentos após confirmação"""
        self.manager.current = 'agendamento_cliente'
    
    def voltar_home(self):
        """Volta para a tela home"""
        self.manager.current = 'home'
    
    def ir_para_perfil(self):
        """Navega para o perfil"""
        self.manager.current = 'perfil'
    
    def logout(self, instance):
        """Realiza logout"""
        app = App.get_running_app()
        app.usuario_id = None
        app.logado = False
        app.foto_perfil = None
        app.tipo_usuario = None
        self.dropdown.dismiss()
        self.manager.current = 'login'
    
    def pesquisar_barbearias(self, texto):
        """Filtra as barbearias baseado no texto de pesquisa"""
        if not hasattr(self, 'ids') or 'barbearias_grid' not in self.ids:
            return
        
        texto = texto.lower().strip()
        self.ids.barbearias_grid.clear_widgets()
        
        # Atualizar número de colunas baseado no tamanho da tela
        self.ids.barbearias_grid.cols = 1 if self.is_mobile else 2
        
        for barbearia in self.barbearias_data:
            if (texto in barbearia['nome'].lower() or 
                texto in barbearia['endereco'].lower() or 
                texto in barbearia['telefone'].lower()):
                
                card = BarbeariaCard(
                    barbearia_id=str(barbearia['id']),
                    nome=barbearia['nome'],
                    endereco=barbearia['endereco'],
                    telefone=barbearia['telefone'],
                    status=barbearia['status'],
                    foto_url=barbearia['foto_url'],
                    possui_agendamento=self.possui_agendamento_ativo
                )
                card.ids.btn_agendar.bind(on_release=lambda instance, bid=barbearia['id'], bnome=barbearia['nome']: 
                                         self.entrar_na_fila(bid, bnome))
                self.ids.barbearias_grid.add_widget(card)