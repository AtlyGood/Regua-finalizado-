from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.scrollview import ScrollView
from kivy.uix.dropdown import DropDown
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, Ellipse
from kivy.uix.behaviors import ButtonBehavior
from kivy.clock import Clock
from kivy.properties import StringProperty, BooleanProperty, NumericProperty, ListProperty
from kivy.metrics import dp, sp
from kivy.uix.widget import Widget
from kivy.core.image import Image as CoreImage
from io import BytesIO
import sqlite3
import os
import requests
from kivy.lang import Builder
usuario = os.getlogin()
Builder.load_file('home_barbeiro.kv')


class ProfileImage(ButtonBehavior, Image):
    """Widget personalizado para exibir imagem de perfil com formato circular"""
    def __init__(self, **kwargs):
        super(ProfileImage, self).__init__(**kwargs)
        self.allow_stretch = True
        self.keep_ratio = False
        
    def on_size(self, *args):
        # Remove o canvas anterior para evitar sobreposição
        self.canvas.before.clear()
        with self.canvas.before:
            # Borda circular - MESMA COR DO AGENDAMENTO_BARB
            Color(0.886, 0.898, 0.918, 1)
            Ellipse(pos=self.pos, size=self.size)
            
            # Imagem arredondada - MESMO ESTILO DO AGENDAMENTO_BARB
            Color(1, 1, 1, 1)
            Ellipse(
                pos=(self.x + dp(2), self.y + dp(2)), 
                size=(self.width - dp(4), self.height - dp(4)),
                source=self.source
            )

class CustomDropDown(DropDown):
    pass

class MenuButton(Button):
    pass

class HomeScreenBarbeiro(Screen):
    profile_photo = StringProperty('')
    is_mobile = BooleanProperty(False)
    background_image = StringProperty('')
    profile_size = NumericProperty(dp(40))  # Nova propriedade para tamanho da foto
    
    def __init__(self, **kwargs):
        super(HomeScreenBarbeiro, self).__init__(**kwargs)
        self.dropdown = CustomDropDown()
        Window.bind(on_resize=self.on_window_resize)
        
        Clock.schedule_once(self.init_ui, 0.1)
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_foto_perfil()
        
    def carregar_foto_perfil(self):
        """Carrega a foto de perfil do usuário logado"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("SELECT foto_perfil FROM regua2_usuario WHERE id = ?", (app.usuario_id,))
                resultado = cursor.fetchone()
                
                if resultado and resultado[0]:
                    foto_path = resultado[0]
                    
                    if foto_path and not os.path.isabs(foto_path):
                        if foto_path.startswith('perfil/'):
                            filename = foto_path.replace('perfil/', '')
                        else:
                            filename = foto_path
                        
                        base_path = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                        foto_path = os.path.join(base_path, filename)
                    
                    if os.path.exists(foto_path):
                        self.profile_photo = foto_path
                        if hasattr(self, 'ids') and 'profile_image' in self.ids:
                            self.ids.profile_image.source = foto_path
                    else:
                        self.definir_imagem_padrao()
                else:
                    self.definir_imagem_padrao()
                    
                conn.close()
            except Exception as e:
                print(f"Erro ao carregar foto: {e}")
                self.definir_imagem_padrao()
        else:
            self.definir_imagem_padrao()
    
    def definir_imagem_padrao(self):
        """Define uma imagem padrão quando não há foto"""
        self.profile_photo = 'assets/default_profile.png'
        if hasattr(self, 'ids') and 'profile_image' in self.ids:
            self.ids.profile_image.source = 'assets/default_profile.png'
    
    def init_ui(self, dt):
        self.check_screen_size()
        
    def on_window_resize(self, window, width, height):
        self.check_screen_size()
        
    def check_screen_size(self):
        """Verifica se está em modo mobile baseado na largura da tela"""
        self.is_mobile = Window.width < dp(768)
        
        # Ajustar tamanho da foto baseado na tela
        if self.is_mobile:
            self.profile_size = dp(40)
        else:
            self.profile_size = dp(40)  # Mantém o mesmo tamanho ou ajuste se necessário
            
        # Atualizar o app global também
        app = App.get_running_app()
        if hasattr(app, 'is_mobile'):
            app.is_mobile = self.is_mobile
    
    def create_dropdown(self):
        self.dropdown.clear_widgets()
        
        options = [
            ('Cadastrar Barbearia', self.go_to_cadastrar_barbearia),
            ('Agendamentos', self.go_to_agendamentos_barb),
            ('Minha Barbearia', self.go_to_minha_barbearia),
            ('Sair', self.logout)
        ]
        
        # Calcular altura total baseada no número de opções
        total_height = len(options) * dp(50)
        
        # Configurar o dropdown
        self.dropdown.max_height = total_height
        self.dropdown.width = dp(250)  # Largura consistente
        
        for text, callback in options:
            btn = MenuButton(
                text=text, 
                size_hint_y=None, 
                height=dp(50),
                size_hint_x=1,  # Para ocupar toda a largura
                color=[1, 0.3, 0.3, 1] if text == 'Sair' else [0, 0, 0, 1],
                font_size=sp(16)  # Tamanho de fonte adequado
            )
            btn.bind(on_release=callback)
            self.dropdown.add_widget(btn)
    
    def go_to_cadastrar_barbearia(self, instance):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'cadastro_barbearia'
            self.dropdown.dismiss()
    
    def go_to_agendamentos_barb(self, instance):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'agendamento_barbeiro'
            self.dropdown.dismiss()

    def go_to_minha_barbearia(self, instance):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'editar_barbearia'
            self.dropdown.dismiss()
    
    def logout(self, instance):
        """Realiza logout do usuário"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id'):
            app.usuario_id = None
            app.logado = False
            app.foto_perfil = None
            
        self.manager.current = 'login'
        self.dropdown.dismiss()
    
    def open_dropdown(self, button):
        self.create_dropdown()
        self.dropdown.open(button)
    
    def go_to_perfil(self):
        if hasattr(self.manager, 'get_screen'):
            self.manager.current = 'perfil'
            self.dropdown.dismiss()