from kivy.uix.screenmanager import Screen
from kivy.metrics import dp
from kivy.utils import get_color_from_hex
import sqlite3
import re
from kivy.app import App
import os 
import django
from django.conf import settings

usuario = os.getlogin()

# Configure Django settings PARA USAR A MESMA CRIPTOGRAFIA
if not settings.configured:
    settings.configure(
        SECRET_KEY='django-insecure-sua-chave-secreta-aqui',  # USE A MESMA DO SEU DJANGO
        USE_TZ=True,
    )
    django.setup()

from django.contrib.auth.hashers import check_password

# Carrega o arquivo KV do login
from kivy.lang import Builder
Builder.load_file('login.kv')

class LoginScreen(Screen):
    def fazer_login(self):
        """Realiza o login do usuário COM VERIFICAÇÃO DJANGO"""
        # Obtém os valores dos campos
        email = self.ids.email_input.text.strip()
        senha = self.ids.senha_input.text.strip()
        
        if not email or not senha:
            self.ids.mensagem_erro.text = "Preencha todos os campos"
            self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            return False
        
        conn = self.conectar_banco()
        if conn:
            try:
                cursor = conn.cursor()
                # CORREÇÃO: Adicionar o campo 'tipo' na consulta
                cursor.execute("SELECT id, senha, tipo, nome, sobrenome FROM regua2_usuario WHERE email = ?", (email,))
                resultado = cursor.fetchone()
                
                if resultado:
                    usuario_id, senha_hash, tipo_usuario, nome, sobrenome = resultado
                    
                    # VERIFICAÇÃO COM CHECK_PASSWORD DO DJANGO
                    if check_password(senha, senha_hash):
                        self.ids.mensagem_erro.text = ""
                        self.ids.mensagem_erro.color = get_color_from_hex('#00AA00')
                        
                        # Armazena os dados do usuário no app
                        app = App.get_running_app()
                        app.usuario_id = usuario_id
                        app.logado = True
                        app.email_usuario = email
                        app.nome_usuario = f"{nome} {sobrenome}" if nome and sobrenome else nome or sobrenome or ""
                        app.tipo_usuario = tipo_usuario  # Armazena o tipo de usuário
                        
                        # Limpa os campos
                        self.ids.email_input.text = ""
                        self.ids.senha_input.text = ""
                        
                        # REDIRECIONAMENTO CONFORME O TIPO DE USUÁRIO
                        if tipo_usuario and str(tipo_usuario).lower().strip() == 'barbearia':
                            self.manager.current = 'home_barbeiro'
                        else:
                            self.manager.current = 'home'
                        
                        return True
                    else:
                        self.ids.mensagem_erro.text = "Senha incorreta"
                        self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                else:
                    self.ids.mensagem_erro.text = "E-mail não encontrado"
                    self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
                    
            except sqlite3.Error as e:
                self.ids.mensagem_erro.text = f"Erro ao fazer login: {e}"
                self.ids.mensagem_erro.color = get_color_from_hex('#FF0000')
            finally:
                conn.close()
        return False
    
    def conectar_banco(self):
        """Conecta ao banco de dados SQLite"""
        try:
            caminho_banco = f"C:\\Users\\{usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            return conn
        except sqlite3.Error as e:
            print(f"Erro ao conectar ao banco: {e}")
            return None
    
    def ir_para_cadastro(self):
        """Navega para a tela de cadastro"""
        self.manager.current = 'cadastro'
        # Limpa os campos ao ir para cadastro
        self.ids.email_input.text = ""
        self.ids.senha_input.text = ""
        self.ids.mensagem_erro.text = ""