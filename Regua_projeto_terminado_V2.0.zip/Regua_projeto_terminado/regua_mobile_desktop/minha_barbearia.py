from kivy.app import App
from kivy.uix.screenmanager import Screen
from kivy.properties import StringProperty
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserIconView
from kivy.logger import Logger
import sqlite3
import os
import shutil
from kivy.lang import Builder

Builder.load_file('minha_barbearia.kv')

class PhotoPopup(Popup):
    def __init__(self, callback, **kwargs):
        super(PhotoPopup, self).__init__(**kwargs)
        self.callback = callback
        self.title = "Selecionar Logo"
        self.size_hint = (0.9, 0.8)
        
        content = BoxLayout(orientation='vertical', padding=10, spacing=10)
        
        self.file_chooser = FileChooserIconView(filters=['*.png', '*.jpg', '*.jpeg'])
        content.add_widget(self.file_chooser)
        
        buttons_layout = BoxLayout(size_hint_y=0.1, spacing=10)
        btn_cancel = Button(text="Cancelar")
        btn_select = Button(text="Selecionar Foto")
        
        btn_cancel.bind(on_release=self.dismiss)
        btn_select.bind(on_release=self.select_photo)
        
        buttons_layout.add_widget(btn_cancel)
        buttons_layout.add_widget(btn_select)
        content.add_widget(buttons_layout)
        
        self.content = content
    
    def select_photo(self, instance):
        if self.file_chooser.selection:
            photo_path = self.file_chooser.selection[0]
            self.dismiss()
            if self.callback:
                self.callback(photo_path)

class MinhaBarbeariaScreen(Screen):
    status_barbearia = StringProperty('aberto')
    foto_path = StringProperty('')
    
    def __init__(self, **kwargs):
        super(MinhaBarbeariaScreen, self).__init__(**kwargs)
        self.barbearia_data = None
        self.usuario = os.getlogin()
        self.status_barbearia = 'aberto'
        self.tem_barbearia = False
        self.popup_aviso = None
        self.foto_selecionada = False
        self.foto_alterada = False  # Para controlar se a foto foi alterada
    
    def on_enter(self):
        """Chamado quando a tela é exibida"""
        self.carregar_dados_barbearia()
    
    def carregar_dados_barbearia(self):
        """Carrega os dados da barbearia do usuário"""
        app = App.get_running_app()
        if hasattr(app, 'usuario_id') and app.usuario_id:
            try:
                caminho_banco = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
                conn = sqlite3.connect(caminho_banco)
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT b.id, b.nome_barbearia, b.telefone_comercial, b.endereco, 
                           b.cidade, b.estado, b.foto_logo, b.status_barbearia
                    FROM regua2_barbearia b
                    WHERE b.usuario_id = ?
                """, (app.usuario_id,))
                
                resultado = cursor.fetchone()
                
                if resultado:
                    self.tem_barbearia = True
                    self.barbearia_data = {
                        'id': resultado[0],
                        'nome_barbearia': resultado[1],
                        'telefone_comercial': resultado[2],
                        'endereco': resultado[3],
                        'cidade': resultado[4],
                        'estado': resultado[5],
                        'foto_logo': resultado[6],
                        'status_barbearia': resultado[7] or 'aberto'
                    }
                    self.preencher_dados_formulario()
                else:
                    self.tem_barbearia = False
                    self.mostrar_popup("Aviso", "Você não possui uma barbearia cadastrada!")
                    self.voltar_home()
                
                conn.close()
                
            except Exception as e:
                Logger.error(f"MinhaBarbearia: Erro ao carregar dados - {str(e)}")
                self.mostrar_popup("Erro", f"Erro ao carregar dados: {str(e)}")
    
    def preencher_dados_formulario(self):
        """Preenche o formulário com os dados da barbearia"""
        if not self.tem_barbearia or not self.barbearia_data:
            return
        
        try:
            # Preenche campos de texto
            self.ids.nome_barbearia.text = self.barbearia_data['nome_barbearia']
            self.ids.telefone_comercial.text = self.barbearia_data['telefone_comercial']
            self.ids.endereco.text = self.barbearia_data['endereco']
            self.ids.cidade.text = self.barbearia_data['cidade']
            self.ids.estado.text = self.barbearia_data['estado']
            
            # Define status
            self.status_barbearia = self.barbearia_data['status_barbearia']
            
            # Carrega foto
            if self.barbearia_data['foto_logo']:
                self.carregar_foto_logo(self.barbearia_data['foto_logo'])
                self.foto_selecionada = True
            else:
                self.definir_imagem_padrao()
            
            # Atualiza botões de status
            if self.status_barbearia == 'aberto':
                self.ids.btn_aberto.state = 'down'
                self.ids.btn_fechado.state = 'normal'
            else:
                self.ids.btn_aberto.state = 'normal'
                self.ids.btn_fechado.state = 'down'
                
        except Exception as e:
            Logger.error(f"MinhaBarbearia: Erro ao preencher formulário - {str(e)}")
    
    def on_status_barbearia(self, instance, value):
        """Atualiza o indicator quando o status muda"""
        pass
    
    def carregar_foto_logo(self, foto_path):
        """Carrega a foto da logo da barbearia"""
        try:
            if foto_path and not os.path.isabs(foto_path):
                # CORREÇÃO: Agora também verifica o caminho "barbearias/logos/"
                if foto_path.startswith('barbearias/logos/'):
                    filename = foto_path.replace('barbearias/logos/', '')
                    base_path = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos"
                    foto_path_abs = os.path.join(base_path, filename)
                elif foto_path.startswith('perfil/'):
                    filename = foto_path.replace('perfil/', '')
                    base_path = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                    foto_path_abs = os.path.join(base_path, filename)
                else:
                    # Tenta encontrar o arquivo em ambos os locais
                    base_path_perfil = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil"
                    base_path_logos = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos"
                    
                    foto_path_perfil = os.path.join(base_path_perfil, foto_path)
                    foto_path_logos = os.path.join(base_path_logos, foto_path)
                    
                    if os.path.exists(foto_path_perfil):
                        foto_path_abs = foto_path_perfil
                    elif os.path.exists(foto_path_logos):
                        foto_path_abs = foto_path_logos
                    else:
                        foto_path_abs = None
            
            if foto_path_abs and os.path.exists(foto_path_abs):
                self.foto_path = foto_path_abs
                self.ids.foto_preview.source = foto_path_abs
                self.ids.placeholder_text.opacity = 0
                self.foto_selecionada = True
            else:
                self.definir_imagem_padrao()
                
        except Exception as e:
            Logger.error(f"MinhaBarbearia: Erro ao carregar foto - {str(e)}")
            self.definir_imagem_padrao()
    
    def definir_imagem_padrao(self):
        """Define a imagem padrão quando não há foto"""
        self.foto_path = ''
        self.ids.foto_preview.source = ''
        self.ids.placeholder_text.opacity = 1
        self.foto_selecionada = False
    
    def selecionar_foto(self):
        """Abre o seletor de arquivos para escolher a logo"""
        popup = PhotoPopup(callback=self.salvar_foto_selecionada)
        popup.open()
    
    def salvar_foto_selecionada(self, photo_path):
        """Processa a foto selecionada"""
        try:
            if photo_path:
                self.ids.foto_preview.source = photo_path
                self.ids.placeholder_text.opacity = 0
                self.foto_path = photo_path
                self.foto_selecionada = True
                self.foto_alterada = True  # Marca que a foto foi alterada
                
        except Exception as e:
            Logger.error(f"MinhaBarbearia: Erro ao processar foto - {str(e)}")
            self.mostrar_popup("Erro", "Erro ao processar a foto selecionada")
    
    def atualizar_status(self, status):
        """Atualiza o status da barbearia"""
        self.status_barbearia = status
        # Atualiza o texto do indicador
        self.ids.status_indicator.text = 'ABERTO' if status == 'aberto' else 'FECHADO'
    
    def formatar_telefone(self):
        """Formata o telefone automaticamente enquanto digita"""
        telefone_input = self.ids.telefone_comercial
        texto = telefone_input.text
        
        # Remove tudo que não é número
        numeros = ''.join(filter(str.isdigit, texto))
        
        # Limita a 11 dígitos
        if len(numeros) > 11:
            numeros = numeros[:11]
            telefone_input.text = self._aplicar_formatacao(numeros)
            telefone_input.cursor = (len(telefone_input.text), 0)
            return
        
        # Aplica formatação
        texto_formatado = self._aplicar_formatacao(numeros)
        
        # Só atualiza se mudou
        if texto != texto_formatado:
            posicao_cursor = telefone_input.cursor[0]
            telefone_input.text = texto_formatado
            
            # Mantém a posição do cursor
            if len(texto_formatado) >= posicao_cursor:
                telefone_input.cursor = (posicao_cursor, 0)
    
    def _aplicar_formatacao(self, numeros):
        """Aplica a formatação baseada no número de dígitos"""
        if len(numeros) <= 2:
            return numeros
        elif len(numeros) <= 6:
            return f"({numeros[:2]}) {numeros[2:]}"
        elif len(numeros) <= 10:
            return f"({numeros[:2]}) {numeros[2:6]}-{numeros[6:]}"
        else:
            return f"({numeros[:2]}) {numeros[2:7]}-{numeros[7:11]}"
    
    def validar_campos(self):
        """Valida se todos os campos obrigatórios estão preenchidos"""
        campos = {
            'nome_barbearia': self.ids.nome_barbearia.text.strip(),
            'telefone_comercial': self.ids.telefone_comercial.text.strip(),
            'endereco': self.ids.endereco.text.strip(),
            'cidade': self.ids.cidade.text.strip(),
            'estado': self.ids.estado.text
        }
        
        for campo, valor in campos.items():
            if not valor or valor == 'Selecione...':
                self.mostrar_popup("Atenção", f"Preencha o campo: {campo.replace('_', ' ').title()}")
                return False
        
        telefone_numeros = ''.join(filter(str.isdigit, campos['telefone_comercial']))
        if len(telefone_numeros) not in [10, 11]:
            self.mostrar_popup("Atenção", "Telefone deve ter 10 ou 11 dígitos")
            return False
        
        return True
    
    def salvar_alteracoes(self):
        """Salva as alterações da barbearia no banco de dados"""
        if not self.validar_campos():
            return
        
        try:
            app = App.get_running_app()
            if not hasattr(app, 'usuario_id') or not app.usuario_id:
                self.mostrar_popup("Erro", "Usuário não logado")
                return
            
            caminho_banco = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            dados = {
                'nome_barbearia': self.ids.nome_barbearia.text.strip(),
                'telefone_comercial': self.ids.telefone_comercial.text.strip(),
                'endereco': self.ids.endereco.text.strip(),
                'cidade': self.ids.cidade.text.strip(),
                'estado': self.ids.estado.text,
                'status_barbearia': self.status_barbearia,
                'barbearia_id': self.barbearia_data['id']
            }
            
            # Processa a foto se foi alterada
            foto_logo_path = None
            if self.foto_alterada and self.foto_path and os.path.exists(self.foto_path):
                # Remove foto antiga se existir
                if self.barbearia_data['foto_logo']:
                    # Verifica onde a foto antiga está salva
                    if self.barbearia_data['foto_logo'].startswith('barbearias/logos/'):
                        filename = self.barbearia_data['foto_logo'].replace('barbearias/logos/', '')
                        old_photo_path = os.path.join(
                            f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos",
                            filename
                        )
                    elif self.barbearia_data['foto_logo'].startswith('perfil/'):
                        filename = self.barbearia_data['foto_logo'].replace('perfil/', '')
                        old_photo_path = os.path.join(
                            f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil",
                            filename
                        )
                    else:
                        # Se não tiver prefixo, tenta em ambos os locais
                        old_photo_path1 = os.path.join(
                            f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos",
                            self.barbearia_data['foto_logo']
                        )
                        old_photo_path2 = os.path.join(
                            f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil",
                            self.barbearia_data['foto_logo']
                        )
                        
                        if os.path.exists(old_photo_path1):
                            old_photo_path = old_photo_path1
                        elif os.path.exists(old_photo_path2):
                            old_photo_path = old_photo_path2
                        else:
                            old_photo_path = None
                    
                    if old_photo_path and os.path.exists(old_photo_path):
                        os.remove(old_photo_path)
                
                # CORREÇÃO: Salva SEMPRE em "barbearias/logos/" com nome original
                nome_arquivo = os.path.basename(self.foto_path)
                
                # Define o caminho de destino CORRETO
                destino_pasta = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\barbearias\\logos"
                
                # Cria a pasta se não existir
                os.makedirs(destino_pasta, exist_ok=True)
                
                # Caminho completo do arquivo
                destino_completo = os.path.join(destino_pasta, nome_arquivo)
                
                # Se já existir um arquivo com o mesmo nome, adiciona um sufixo numérico
                contador = 1
                nome_base, extensao = os.path.splitext(nome_arquivo)
                while os.path.exists(destino_completo):
                    nome_arquivo = f"{nome_base}_{contador}{extensao}"
                    destino_completo = os.path.join(destino_pasta, nome_arquivo)
                    contador += 1
                
                # Copia a imagem para o destino correto
                shutil.copy2(self.foto_path, destino_completo)
                
                # Salva apenas o caminho relativo no banco
                foto_logo_path = f"barbearias/logos/{nome_arquivo}"
            
            # Atualiza os dados da barbearia
            if foto_logo_path:
                cursor.execute("""
                    UPDATE regua2_barbearia 
                    SET nome_barbearia = ?, telefone_comercial = ?, endereco = ?,
                        cidade = ?, estado = ?, foto_logo = ?, status_barbearia = ?
                    WHERE id = ?
                """, (
                    dados['nome_barbearia'], dados['telefone_comercial'],
                    dados['endereco'], dados['cidade'], dados['estado'],
                    foto_logo_path, dados['status_barbearia'], dados['barbearia_id']
                ))
            else:
                # Se não alterou a foto, mantém a atual
                cursor.execute("""
                    UPDATE regua2_barbearia 
                    SET nome_barbearia = ?, telefone_comercial = ?, endereco = ?,
                    cidade = ?, estado = ?, status_barbearia = ?
                    WHERE id = ?
                """, (
                    dados['nome_barbearia'], dados['telefone_comercial'],
                    dados['endereco'], dados['cidade'], dados['estado'],
                    dados['status_barbearia'], dados['barbearia_id']
                ))
            
            conn.commit()
            conn.close()
            
            self.mostrar_popup("Sucesso", "Barbearia atualizada com sucesso!")
            self.voltar_home()
            
        except Exception as e:
            Logger.error(f"MinhaBarbearia: Erro ao salvar - {str(e)}")
            self.mostrar_popup("Erro", f"Erro ao salvar alterações: {str(e)}")
    
    def cancelar(self):
        """Cancela e volta para a tela anterior"""
        self.voltar_home()
    
    def voltar_home(self):
        """Volta para a tela home correta"""
        app = App.get_running_app()
        if hasattr(app, 'tipo_usuario') and app.tipo_usuario == 'barbearia':
            self.manager.current = 'home_barbeiro'
        else:
            self.manager.current = 'home'
    
    def excluir_barbearia(self):
        """Abre popup de confirmação para excluir barbearia"""
        content = BoxLayout(orientation='vertical', padding=20, spacing=20)
        
        label = Label(
            text='Tem certeza que deseja excluir a barbearia?\n\n'
                 'Esta ação não pode ser desfeita e todos os dados serão permanentemente removidos, incluindo agendamentos e histórico.',
            text_size=(400, None),
            halign='center',
            valign='middle'
        )
        
        buttons_layout = BoxLayout(spacing=10, size_hint_y=0.3)
        
        btn_cancelar = Button(text='Cancelar', background_color=(0.392, 0.455, 0.545, 1))
        btn_cancelar.bind(on_release=self.fechar_popup_exclusao)
        
        btn_excluir = Button(text='Sim, Excluir', background_color=(0.937, 0.267, 0.267, 1))
        btn_excluir.bind(on_release=self.confirmar_exclusao)
        
        buttons_layout.add_widget(btn_cancelar)
        buttons_layout.add_widget(btn_excluir)
        
        content.add_widget(label)
        content.add_widget(buttons_layout)
        
        self.popup_exclusao = Popup(
            title='Confirmar Exclusão',
            content=content,
            size_hint=(0.8, 0.6),
            auto_dismiss=False
        )
        
        self.popup_exclusao.open()
    
    def fechar_popup_exclusao(self, instance):
        """Fecha o popup de exclusão"""
        if hasattr(self, 'popup_exclusao'):
            self.popup_exclusao.dismiss()
    
    def confirmar_exclusao(self, instance):
        """Confirma e executa a exclusão da barbearia"""
        try:
            app = App.get_running_app()
            caminho_banco = f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\db.sqlite3"
            conn = sqlite3.connect(caminho_banco)
            cursor = conn.cursor()
            
            # Remove a foto se existir
            if self.barbearia_data['foto_logo']:
                old_photo_path = os.path.join(
                    f"C:\\Users\\{self.usuario}\\Desktop\\Regua_projeto_terminado\\projeto_web\\regua\\perfil",
                    self.barbearia_data['foto_logo'].replace('perfil/', '')
                )
                if os.path.exists(old_photo_path):
                    os.remove(old_photo_path)
            
            # Exclui a barbearia
            cursor.execute("DELETE FROM regua2_barbearia WHERE id = ?", (self.barbearia_data['id'],))
            
            # Atualiza o tipo do usuário para cliente
            cursor.execute("UPDATE regua2_usuario SET tipo = 'cliente' WHERE id = ?", (app.usuario_id,))
            
            conn.commit()
            conn.close()
            
            self.fechar_popup_exclusao(None)
            self.mostrar_popup("Sucesso", "Barbearia excluída com sucesso!")
            self.voltar_home()
            
        except Exception as e:
            Logger.error(f"MinhaBarbearia: Erro ao excluir - {str(e)}")
            self.mostrar_popup("Erro", f"Erro ao excluir barbearia: {str(e)}")
    
    def mostrar_popup(self, title, message):
        """Exibe um popup de mensagem"""
        popup = Popup(
            title=title,
            content=Label(text=message, padding=20),
            size_hint=(0.7, 0.3)
        )
        popup.open()