import pymysql
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.image import Image
from kivy.uix.anchorlayout import AnchorLayout



usuario_logado = ''

# Conexão com o banco
def conectar_banco():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='senac',
        database='REGUA',
        port=3307
    )

class MenuInicialScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

        titulo = Label(text='[color=00FF00]R[/color]EGUA', font_size=32, size_hint=(1, 0.1), markup=True)
        layout.add_widget(titulo)

        # Colocar a imagem dentro de um AnchorLayout para centralizar
        anchor = AnchorLayout(anchor_x='center', anchor_y='center', size_hint=(1, 0.6))
        imagem = Image(source="C:/Users/Anthony54245016/Desktop/Regua/REGUA LOGO.png", size_hint=(None, None), size=(300, 300))
        anchor.add_widget(imagem)

        layout.add_widget(anchor)

        # Botões em BoxLayout vertical
        botoes_layout = BoxLayout(orientation='vertical', spacing=10, size_hint=(1, 0.3))

        btn_barbearias = Button(text='Barbearias')
        btn_planos = Button(text='Planos')
        btn_clientes = Button(text='Clientes')
        btn_infos = Button(text='Minhas Informações')

        botoes_layout.add_widget(btn_barbearias)
        botoes_layout.add_widget(btn_planos)
        botoes_layout.add_widget(btn_clientes)
        botoes_layout.add_widget(btn_infos)

        layout.add_widget(botoes_layout)

        self.add_widget(layout)

# Tela de Login
class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

        layout.add_widget(Label(text='Login', font_size=32, size_hint=(1, 0.2)))
        self.email_input = TextInput(hint_text='Email', multiline=False, size_hint=(1, 0.2))
        self.senha_input = TextInput(hint_text='Senha', multiline=False, password=True, size_hint=(1, 0.2))

        layout.add_widget(self.email_input)
        layout.add_widget(self.senha_input)

        login_button = Button(text='Entrar', size_hint=(1, 0.2), background_color=(0, 1, 0, 1))  # Verde
        login_button.bind(on_press=self.fazer_login)
        layout.add_widget(login_button)

        cadastro_button = Button(text='Cadastrar', size_hint=(1, 0.2), background_color=(0, 0.5, 1, 1))  # Azul
        cadastro_button.bind(on_press=lambda x: setattr(self.manager, 'current', 'cadastro'))
        layout.add_widget(cadastro_button)

        excluir_button = Button(text='Excluir Conta', size_hint=(1, 0.2), background_color=(1, 0, 0, 1))  # Vermelho
        excluir_button.bind(on_press=lambda x: setattr(self.manager, 'current', 'excluir'))
        layout.add_widget(excluir_button)

        self.add_widget(layout)

    def fazer_login(self, instance):
        global usuario_logado
        email = self.email_input.text
        senha = self.senha_input.text

        try:
            conn = conectar_banco()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM usuarios WHERE email = %s AND senha = %s", (email, senha))
            resultado = cursor.fetchone()
            conn.close()

            if resultado:
                usuario_logado = email
                self.exibir_popup("Login realizado com sucesso.")
                self.manager.current = 'menu'
            else:
                self.exibir_popup("Login inválido")

        except Exception as e:
            self.exibir_popup(f'Erro ao conectar: {e}')

    def exibir_popup(self, mensagem):
        popup = Popup(title='Login', content=Label(text=mensagem), size_hint=(0.7, 0.4))
        popup.open()

# Tela de Cadastro
class CadastroScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

        layout.add_widget(Label(text='Cadastro', font_size=28))
        self.email_input = TextInput(hint_text='Email', multiline=False)
        self.senha_input = TextInput(hint_text='Senha', multiline=False, password=True)

        cadastrar_button = Button(text='Cadastrar', background_color=(0, 0.5, 1, 1))  # Azul
        cadastrar_button.bind(on_press=self.cadastrar)

        voltar_button = Button(text='Voltar', background_color=(1, 0, 0, 1))  # vermelho
        voltar_button.bind(on_press=lambda x: setattr(self.manager, 'current', 'login'))

        layout.add_widget(self.email_input)
        layout.add_widget(self.senha_input)
        layout.add_widget(cadastrar_button)
        layout.add_widget(voltar_button)

        self.add_widget(layout)

    def cadastrar(self, instance):
        email = self.email_input.text
        senha = self.senha_input.text

        try:
            conn = conectar_banco()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO usuarios (EMAIL, SENHA) VALUES (%s, %s)", (email, senha))
            conn.commit()
            conn.close()
            self.exibir_popup("Cadastro realizado com sucesso!")
            setattr(self.manager, 'current', 'login')
        except Exception as e:
            self.exibir_popup(f"Erro: {e}")

    def exibir_popup(self, mensagem):
        popup = Popup(title='Cadastro', content=Label(text=mensagem), size_hint=(0.7, 0.4))
        popup.open()

# Tela de Exclusão
class ExcluirContaScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)

        layout.add_widget(Label(text='Excluir Conta', font_size=28))
        self.email_input = TextInput(hint_text='Email', multiline=False)
        self.senha_input = TextInput(hint_text='Senha', multiline=False, password=True)

        excluir_button = Button(text='Excluir Conta')
        excluir_button.bind(on_press=self.excluir)

        voltar_button = Button(text='Voltar')
        voltar_button.bind(on_press=lambda x: setattr(self.manager, 'current', 'login'))

        layout.add_widget(self.email_input)
        layout.add_widget(self.senha_input)
        layout.add_widget(excluir_button)
        layout.add_widget(voltar_button)

        self.add_widget(layout)

    def excluir(self, instance):
        email = self.email_input.text
        senha = self.senha_input.text

        try:
            conn = conectar_banco()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM usuarios WHERE EMAIL = %s AND SENHA = %s", (email, senha))
            conn.commit()
            conn.close()

            if cursor.rowcount > 0:
                self.exibir_popup("Conta excluída com sucesso.")
            else:
                self.exibir_popup("Conta não encontrada.")

        except Exception as e:
            self.exibir_popup(f"Erro: {e}")

    def exibir_popup(self, mensagem):
        popup = Popup(title='Excluir Conta', content=Label(text=mensagem), size_hint=(0.7, 0.4))
        popup.open()

# App principal
class MeuApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(CadastroScreen(name='cadastro'))
        sm.add_widget(ExcluirContaScreen(name='excluir'))
        sm.add_widget(MenuInicialScreen(name='menu'))
        return sm

if __name__ == '__main__':
    MeuApp().run()
